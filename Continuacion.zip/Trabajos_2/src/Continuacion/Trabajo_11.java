/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Continuacion;

import java.util.Scanner;

/**
 *
 * @author Sebas
 */
public class Trabajo_11 {

    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);

        System.out.print("Escribe el primer numero:");
        int numero1 = entrada.nextInt();

        System.out.print("Escribe el segundo numero:");
        int numero2 = entrada.nextInt();

        int distancia = Math.abs(numero1 - numero2);
        System.out.print("La distancia de los dos numeros sera de:" + distancia);

    }

}
