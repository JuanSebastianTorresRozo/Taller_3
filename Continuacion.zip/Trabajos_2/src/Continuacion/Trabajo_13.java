/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Continuacion;

import java.util.Scanner;

/**
 *
 * @author Sebas
 */
public class Trabajo_13 {

    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);
        System.out.print("Escribe el numero:");
        int numero = entrada.nextInt();

        System.out.println("La raiz cuadrada de :" + numero + "Sera:" + Math.sqrt(numero));
        System.out.println("La raiz cubica de :" + numero + "Sera:" + Math.cbrt(numero));

    }
}
