/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Continuacion;

import java.util.Scanner;

/**
 *
 * @author Sebas
 */
public class Trabajo_16 {

    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);

        System.out.print("Digite la velocidad del primer vehiculo:");
        double velocidad1 = entrada.nextDouble();

        System.out.print("Digite la velocidad del segundo vehiculo:");
        double velocidad2 = entrada.nextDouble();

        while (velocidad1 >= velocidad2) {

            System.out.println("La velocidad 2 debe ser mayor");
            System.exit(0);
        }

        System.out.print("Digite la distancia de los vehiculos:");
        double distancia = entrada.nextDouble();

        System.out.println("La velocidad del primer vehiculo sera:" + velocidad1 + "km");

        System.out.println("La velocidad del segundo vehiculo sera:" + velocidad2 + "km");

        System.out.println("La distancia de los vehiculos sera:" + distancia + "metros");

        double tiempoAlcance =Math.abs( distancia / (velocidad1 - velocidad2) * 60);

        System.out.println("El vehículo más rápido alcanzará al otro en " + tiempoAlcance + " minutos.");

    }
}
