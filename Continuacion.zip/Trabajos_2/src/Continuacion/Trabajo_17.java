/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Continuacion;

import java.util.Scanner;

/**
 *
 * @author Sebas
 */
public class Trabajo_17 {

    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);

        System.out.print("Introduce la hora de partida (HH): ");
        int horaPartida = entrada.nextInt();

        System.out.print("Introduce los minutos de partida (MM): ");
        int minPartida = entrada.nextInt();

        System.out.print("Introduce los segundos de partida (SS): ");
        int segPartida = entrada.nextInt();

        System.out.print("Introduce el tiempo de viaje en segundos (T): ");
        int tiempoV = entrada.nextInt();

        int totalSegundos = horaPartida * 3600 + minPartida * 60 + segPartida + tiempoV;

        int horaLlegada = totalSegundos / 3600;

        int minLlegada = (totalSegundos - horaLlegada * 3600) / 60;

        int segLlegada = totalSegundos - horaLlegada * 3600 - minLlegada * 60;

        System.out.printf("La hora de llegada a la ciudad B es %02d:%02d:%02d.", horaLlegada, minLlegada, segLlegada);
    }

}
