/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Continuacion;

import java.util.Scanner;

/**
 *
 * @author Sebas
 */
public class Trabajo_15 {

    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);

        System.out.print("Ingrese el numero A:");
        double numeroA = entrada.nextDouble();

        System.out.print("Ingrese el numero B:");
        double numeroB = entrada.nextDouble();

        System.out.println("El numero A sera:" + numeroA + "Pero tomara el valor de:" + numeroB);
        
         System.out.println("El numero B sera:" + numeroB + "Pero tomara el valor de:" + numeroA);
    }
}
