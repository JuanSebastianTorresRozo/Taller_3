/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Continuacion;

import java.util.Scanner;

/**
 *
 * @author Sebas
 */
public class Trabajo_12 {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        System.out.print("Ingrese el primer valor de X:");
        int x1 = entrada.nextInt();

        System.out.print("Ingrese el primer valor de Y:");
        int y1 = entrada.nextInt();

        System.out.print("Ingrese el segundo valor de X:");
        int x2 = entrada.nextInt();

        System.out.print("Ingrese el segundo valor de Y:");
        int y2 = entrada.nextInt();
        
        System.out.print("La distancia de estos puntos seran:"+ Math.sqrt(Math.abs(x2-x1)*2)+(y2-y1)*2);
    }
}
