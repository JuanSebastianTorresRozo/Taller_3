/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Trabajos;

import java.util.Scanner;
import java.math.BigDecimal;

/**
 *
 * @author ROZO
 */
public class Taller_3 {
    public static void main (String[]args){
        Scanner entrada = new Scanner(System.in);

        System.out.print("Ingrese la longitud del primer lado: ");
        double lado1 = entrada.nextDouble();

        System.out.print("Ingrese la longitud del segundo lado: ");
        double lado2 = entrada.nextDouble();

        double hipotenusa = Math.sqrt(Math.pow(lado1, 2) + Math.pow(lado2, 2));

        System.out.println("La hipotenusa del triángulo rectángulo es: " + hipotenusa);
    }
}
    
    
