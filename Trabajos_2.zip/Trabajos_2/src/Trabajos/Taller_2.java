/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Trabajos;

import java.util.Scanner;

/**
 *
 * @author ROZO
 */
public class Taller_2 {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        double altura;
        double base;
        System.out.print("Digite su base:");
        base=entrada.nextDouble();
        System.out.println("Digite su altura:");
        altura=entrada.nextDouble();
         System.out.println("El perimetro va a ser:"+ (base+altura));
         System.out.println("La altura va a ser:"+ (base*altura)/2);
        
    }
}
