/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Trabajos;

import java.util.Scanner;

/**
 *
 * @author ROZO
 */
public class Taller_6 {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        System.out.print("Ingrese el primer número: ");
        double num1 = entrada.nextDouble();

        System.out.print("Ingrese el segundo número: ");
        double num2 = entrada.nextDouble();

        System.out.print("Ingrese el tercer número: ");
        double num3 = entrada.nextDouble();

        System.out.print("Ingrese el cuarto número: ");
        double num4 = entrada.nextDouble();

        double media = (num1 + num2 + num3 + num4) / 4;

        System.out.println("La media de los números ingresados es: " + media);
    }

}
