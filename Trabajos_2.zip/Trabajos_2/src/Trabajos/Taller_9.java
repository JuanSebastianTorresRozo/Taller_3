/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Trabajos;

import java.util.Scanner;

/**
 *
 * @author ROZO
 */
public class Taller_9 {
    public static void main(String[]args){
    Scanner entrada = new Scanner(System.in);
    int Venta;
    System.out.print("Digite El valor de la venta:");
    Venta=entrada.nextInt(); 
    int Descuento=(Venta*15)/100;
    System.out.print("El Total de la venta sera:"+(Venta-Descuento));
    
    
    }
}
