/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Trabajos;

import java.util.Scanner;

/**
 *
 * @author ROZO
 */
public class Taller_4 {
    public static void main(String[]args){
         Scanner entrada = new Scanner(System.in);
         System.out.print("Digite el primer numero:");
         double numero1= entrada.nextDouble();
          System.out.print("Digite el segundo numero:");
         double numero2= entrada.nextDouble();
        System.out.println("La suma de los dos va a ser :"+ (numero1+numero2));
         System.out.println("La resta de los dos va a ser :"+ (numero1-numero2));
          System.out.println("La multiplicacion de los dos va a ser :"+ (numero1*numero2));
          if (numero2 >0 ){
              System.out.println("La division de los dos va a ser:"+(numero1/numero2));
          
          }else{
          System.out.println("NO SE PUEDE DIVIDIR ENTRE 0");
          }
    }
    }

