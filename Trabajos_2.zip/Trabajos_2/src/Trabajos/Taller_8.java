/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Trabajos;

import java.util.Scanner;

/**
 *
 * @author ROZO
 */
public class Taller_8 {

    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);

        System.out.print("Ingrese el sueldo base del vendedor: ");
        double sueldoBase = entrada.nextDouble();

        System.out.print("Ingrese el monto de la primera venta: ");
        double venta1 = entrada.nextDouble();

        System.out.print("Ingrese el monto de la segunda venta: ");
        double venta2 = entrada.nextDouble();

        System.out.print("Ingrese el monto de la tercera venta: ");
        double venta3 = entrada.nextDouble();

        double comisionTotal = (venta1 + venta2 + venta3) * 0.1;

        double salarioTotal = sueldoBase + comisionTotal;

        System.out.println("La comisión total por las tres ventas realizadas es: " + comisionTotal);
        System.out.println("El salario total del vendedor en el mes es: " + salarioTotal);

    }
}
