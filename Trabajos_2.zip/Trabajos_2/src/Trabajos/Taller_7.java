/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Trabajos;

import java.util.Scanner;

/**
 *
 * @author ROZO
 */
public class Taller_7 {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        int minutos;
        System.out.print("Digite la cantidad de minutos:");
        minutos = entrada.nextInt();
        System.out.println("La cantidad de horas sera:" + (minutos / 60));
        System.out.println("La cantidad de segundos sera::" + (minutos * 60));
    }
}
