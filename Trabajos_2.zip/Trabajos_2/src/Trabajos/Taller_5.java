/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Trabajos;

import java.util.Scanner;

/**
 *
 * @author ROZO
 */
public class Taller_5 {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        double temperatura;
        System.out.print("Digite su temperatura:");
        temperatura = entrada.nextDouble();
        System.out.println("La temperatura en Fahrenheit:" + temperatura);

        System.out.println("La temperatura en celcius:" + (32 * temperatura - 32) * 5 / 9);
    }
}
